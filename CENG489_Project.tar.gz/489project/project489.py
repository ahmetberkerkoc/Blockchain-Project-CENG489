import json

from eth_account import Account
from eth_account.messages import encode_defunct
from web3 import Web3
import sha3
import time

contractAddress = "0x5C64799B61CD764909a47509fdDf6D3D69690BF6"
nodeProvider = "https://kovan.infura.io/v3/e43d1353c1c94ac2a11e4a30c0713083"
clientAddress = "0x8760b0E1962A2939335cfa36516b4803C3965575"
clientPrivateKey = "0x90bc7a57483c7bde0afe88299a5e38961fc2c0e34d763fc342218e1571f9dd7a"
berkerPrivateKey = "0xad15992085309126ad3c0c39399c6de683cd91316034e5c3b77d20708f7bcfcf"
berkerPublicKey = '0xEcd56205ae3A42e616D19780C78F898D931528B6'
web3 = Web3(Web3.HTTPProvider(nodeProvider))
contract = web3.eth.contract(address=contractAddress, abi=json.loads(open('abi2.json').read()))

def test(address):
    hashByteArray = web3.keccak(hexstr=address)
    sig = web3.eth.account.signHash(hashByteArray, clientPrivateKey)

    nonce = web3.eth.getTransactionCount(address)
    txn = contract.functions.BCTrustV2_VerifyTest(address,  web3.toHex(sig.r), web3.toHex(sig.s),clientAddress).buildTransaction({
        'chainId': 42,
        'gas': 100000,
        'gasPrice': web3.eth.gasPrice,
        'nonce': nonce,
    }
    )
    signed_txn = web3.eth.account.signTransaction(txn, private_key=berkerPrivateKey)
    result = web3.eth.sendRawTransaction(signed_txn.rawTransaction)
    tx_receipt = web3.eth.waitForTransactionReceipt(result)
    print(tx_receipt)
    return tx_receipt




def addGroupMaster(groupId, address,privateKey):
    start_time =time.time()
    nonce = web3.eth.getTransactionCount(address)
    txn = contract.functions.BCTrustV2_AddNode(0,groupId,0,0).buildTransaction({
        'chainId': 42,
        'gas': 100000,
        'gasPrice': web3.eth.gasPrice,
        'nonce': nonce,
    }
    )
    signed_txn = web3.eth.account.signTransaction(txn, private_key=privateKey)
    result = web3.eth.sendRawTransaction(signed_txn.rawTransaction)
    print("Transaction on progress.Please wait!!!")
    tx_receipt = web3.eth.waitForTransactionReceipt(result)
    calculateTranscationFee(tx_receipt)
    end_time = time.time()
    # print(result)
    print(f'Execution time : {end_time-start_time} seconds.')
    return tx_receipt
def addGroupMember(groupId, address,r,s,privateKey):
    start_time = time.time()
    nonce = web3.eth.getTransactionCount(address)
    txn = contract.functions.BCTrustV2_AddNode(1, groupId, r, s).buildTransaction({
        'chainId': 42,
        'gas': 100000,
        'gasPrice': web3.eth.gasPrice,
        'nonce': nonce,
    }
    )
    signed_txn = web3.eth.account.signTransaction(txn, private_key=privateKey)
    print("Transaction on progress.Please wait!!!")
    result = web3.eth.sendRawTransaction(signed_txn.rawTransaction)
    tx_receipt = web3.eth.waitForTransactionReceipt(result)
    calculateTranscationFee(tx_receipt)
    end_time = time.time()
    print(f'Execution time : {end_time - start_time} seconds.')
    return tx_receipt

def computeRS(adress, groupId,privateKey):
    #adress  = int(adress,16)
    stringrs =  str(hex(groupId)) + adress[2:]
    hashByteArray = web3.keccak(hexstr=stringrs)

    sig = web3.eth.account.signHash(hashByteArray,private_key=privateKey)
    r = sig.r
    s = sig.s
    return (r,s)

def getGroupId(address):
    result = contract.functions.getUserGroup(address).call()
    # print(result)
    return result


def control(addressSender, addressReceiver):
    result = contract.functions.controlOff(addressSender, addressReceiver).call()
    # print(result)
    return result

def sendMessage(message, senderPublicKey, senderPrivateKey):
    sig = Account.sign_message(encode_defunct(text=message),senderPrivateKey)
    return (sig, senderPublicKey,message)
def receiveMessage(signature,senderPublicKey,message,receiverPubKey):
    start_time = time.time()
    pubKeySender = Account.recover_message(encode_defunct(text=message), vrs=(hex(signature.v),hex(signature.r),hex(signature.s)))
    if pubKeySender!=senderPublicKey:
         print("Sender message is not verified")
         return False
    print("Sender message verified.")
    print("Transaction on progress.Please wait!!!")
    if not control(senderPublicKey,receiverPubKey):
        print("You do not have permission to send message this user")
        return False
    print("User permission sufficient")
    print("Your message has taken")
    end_time = time.time()
    print(f'Execution time : {end_time - start_time} seconds.')
    return True
def simulation():
    sig, senderPublicKey, message = sendMessage("helloWorld", clientAddress,clientPrivateKey)
    receiveMessage(sig,senderPublicKey,message)

def calculateTranscationFee(tx_recepit):
    print(f'Transaction fee: {tx_recepit.effectiveGasPrice*tx_recepit.gasUsed/(10**18)} Ether')


# if __name__== '__main__':
    #print(computeRS(berkerPublicKey, 3))
    # print(addGroupMaster(2,clientAddress))
    # print(addGroupMember(2, berkerPublicKey))
    #test(berkerPublicKey)


    # getGroupId(berkerPublicKey)
    # control(clientAddress,berkerPublicKey)
    # simulation()
