from project489 import *

groupMasters = {

}
users = {

}
class User:
    address=''
    groupId=0
    privateKey=''
def projectSimulation():
    while True:
        try:
            print("to create a group press 1")
            print("to join a group  press 2")
            print("to send a message press 3")
            inputTyepe=int(input())
            if  inputTyepe == 1:
                print("Enter groupId:")
                groupId = int(input())
                print("Enter Public Key:")
                pubKey = input()
                print("Enter Private Key:  Note:only for simulation purpose!")
                privateKey=input()
                result = addGroupMaster(groupId,pubKey,privateKey)
                if result.status == 0:
                    print(f"Aldready master in group: {groupId} ")
                elif result.status ==1:
                    user = User()
                    user.groupId = groupId
                    user.privateKey = privateKey
                    user.address = pubKey
                    users[pubKey] = user
                    groupMasters[groupId] = user
                    print(f"You are group master of group {groupId} ")
                else:
                    print("Something went wrong!!!")
            elif inputTyepe == 2:
                print("Enter groupId:")
                groupId = int(input())
                print("Enter Public Key:")
                pubKey = input()
                print("Enter Private Key:  Note:only for simulation purpose!")
                privateKey = input()
                if groupId not in groupMasters:
                    print("There is no group for this simulation")
                    print("If you know group master exist for this group, you need to enter privateKey of group  master: ")
                    print("To continue press 1 otherwise 0:")
                    inp = int(input())
                    if inp == 0:
                        continue
                    elif inp == 1:
                        print("Enter group master Private Key:")
                        groupMasterPrivateKey = input()
                    else:
                        print("wrong commmand ")
                        continue
                    r,s=computeRS(pubKey,groupId,groupMasterPrivateKey)
                    result = addGroupMember(groupId,pubKey,r,s,privateKey)
                    if result.status == 0:
                        print(f"There is no group master in group {groupId} or group masters did not validate this message!!! ")
                    elif result.status == 1:
                        print(f"You are group member of group {groupId} ")
                        user = User()
                        user.groupId = groupId
                        user.privateKey = privateKey
                        user.address = pubKey
                        users[pubKey] = user


                    else:
                        print("Something went wrong!!!")
                else:
                    r, s = computeRS(pubKey, groupId, groupMasters[groupId].privateKey)
                    result = addGroupMember(groupId, pubKey, r, s, privateKey)
                    if result.status == 0:
                        print(
                            f"There is no group master in group {groupId} or group masters did not validate this message!!! ")
                    elif result.status == 1:
                        user = User()
                        user.groupId=groupId
                        user.privateKey=privateKey
                        user.address=pubKey
                        users[pubKey] = user
                        print(f"You are group member of group {groupId} ")

                    else:
                        print("Something went wrong!!!")
            elif inputTyepe == 3:
                print("Print your message:")
                message=input()
                print("Enter Public Key:")
                pubKey = input()
                print("Enter Private Key:  Note:only for simulation purpose!")
                privateKey = input()
                print("You need to enter receiver public key Note:for simulation purpose!")
                receiverPubKey =input()
                sig,senderPubkey,senderMessage = sendMessage(message,pubKey,privateKey)
                print("You sent a message")
                receiveMessage(sig,senderPubkey,senderMessage,receiverPubKey)

            else:
                print("Invalid command!!!")
        except Exception as e:
            print(e)


if __name__== '__main__':
    projectSimulation()

